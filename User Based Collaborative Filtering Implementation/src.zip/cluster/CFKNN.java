package cluster;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.PriorityQueue;

public class CFKNN {
	
	static int cntUser = 944;
	static int cntItem = 1683;

	public static void main(String[] args) throws IOException {
		int UserOrItem = Integer.parseInt(args[1]);
		int evalMetric = Integer.parseInt(args[5]);
		//String UserOrItem = "1";
		int k = Integer.parseInt(args[3]);
		
		//int k = Integer.parseInt(args[3]);
		
		if(UserOrItem == 0)
		{
			int[][] datasetTrain = fileLoader("train.txt");
			for(int i=0 ; i< datasetTrain.length; i++)
			{
				for(int j=0 ; j < datasetTrain[i].length;j++)
				{
					//System.out.println(datasetTrain[i][j] +" ");
				}
			}
			int[][] datasetTest = fileLoader("test.txt");

//			@SuppressWarnings("rawtypes")
			@SuppressWarnings("rawtypes")
			PriorityQueue[] KNearestNeighbor = SimilarityforNeighbor(datasetTest, datasetTrain, k);
			double[][] testPredictions;
			testPredictions = predict(KNearestNeighbor, datasetTrain,evalMetric);
			if(evalMetric ==0)
			System.out.println("MAE: "+ Errorprediction(datasetTest,testPredictions));
			PrintWriter printWriter = new PrintWriter(new FileWriter(new File("out.txt")));

			for (int i = 1; i < 943; i++) {
				for (int j = 1; j < 1682; j++) {
					printWriter.println(i + "\t" + j + "\t" + testPredictions[i][j]);
					//System.out.println(i + "\t" + j + "\t" + testPredictions[i][j]);
					
				}
			}
			printWriter.close();
		}
		else 
		{
			cntUser = 1683;
			cntItem = 944;
			int[][] datasetTrain = fileLoaderOne("train.txt");
			for(int i=0 ; i< datasetTrain.length; i++)
			{
				for(int j=0 ; j < datasetTrain[i].length;j++)
				{
					//System.out.println(datasetTrain[i][j] +" ");
				}
			}
			int[][] datasetTest = fileLoaderOne("test.txt");
			@SuppressWarnings("rawtypes")
			PriorityQueue[] KNearestNeighbor = SimilarityforNeighbor(datasetTest, datasetTrain, k);
			double[][] testPredictions;
			testPredictions = predict(KNearestNeighbor, datasetTrain,evalMetric);
			System.out.println("MAE: "+Errorprediction(datasetTest,testPredictions));
			PrintWriter printWriter = new PrintWriter(new FileWriter(new File("prediction.txt")));
			for (int i = 1; i < 943; i++) {
				for (int j = 1; j < 1682; j++) {
					printWriter.println(i + "\t" + j + "\t" + testPredictions[j][i]);
					//System.out.println(i + "\t" + j + "\t" + testPredictions[i][j]);
					
				}
			}
			printWriter.close();
		}
	}

	private static double Errorprediction(int[][] datasetTest, double[][] testPredictions) {
		// TODO Auto-generated method stub
		double MAE = 0.0;
		double error = 0.0;
		int cnt1 =0;
		int cnt2 =0;
		for(int i=1; i<datasetTest.length; i++)
		{
			for(int j=1;j<datasetTest[i].length;j++)
			{
				
				if(datasetTest[i][j] != 0.0)
				{
					error += Math.abs(datasetTest[i][j] - testPredictions[i][j]);
					cnt1++;
					if(datasetTest[i][j] > 3.0)
					{
						cnt2++;
					}
				}
			}
		}
		return (error/(double) cnt1);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static double[][] predict(PriorityQueue[] KNearestNeighbor, int[][] datasetTrain, int evalMetric) {
		double[][] testPredictions = new double[cntUser][cntItem];
		boolean flag;
		int relcnt = 0;
		int nonrelcnt = 0;
		for (int index = 1; index < KNearestNeighbor.length; index++) {
			//double similarityAdd = getSimilarityAdd(KNearestNeighbor[index]);
			for (int i = 1; i < cntItem; i++) {
				flag = false;
				double similarityAdd = 0.0;
				double numerator = 0.0;
				for (Object obj : KNearestNeighbor[index]) {
					UserAndSimilarity user = (UserAndSimilarity) obj;
					if (datasetTrain[user.userid][i] != 0) {
						flag = true;
						numerator += datasetTrain[user.userid][i] * user.similarity;
						similarityAdd +=  user.similarity;
						relcnt++;
						if(datasetTrain[user.userid][i]>3.0)
						{
							nonrelcnt++;
						}
					}
				}
				testPredictions[index][i] = flag == true ? (numerator / similarityAdd) : 3.5;

			}
		}
		if(evalMetric==1)
		System.out.println("Precision: " +((double) nonrelcnt/(double)(relcnt))*100 + "%");

		return testPredictions;
	}
	
	@SuppressWarnings("unused")
	private static double getSimilarityAdd(PriorityQueue<UserAndSimilarity> topK) {
		double similarityAdd = 0.0;
		for (UserAndSimilarity user : topK)
			similarityAdd += user.similarity;
		return similarityAdd;
	}

	@SuppressWarnings("rawtypes")
	private static PriorityQueue[] SimilarityforNeighbor(int[][] datasetTest, int[][] datasetTrain, int k) {
		PriorityQueue[] topK = new PriorityQueue[datasetTest.length];
		for (int i = 1; i < datasetTest.length; i++) {
			topK[i] = Similarity(datasetTest[i], datasetTrain, k);
			//System.out.println(topK[i]);
		}
		return topK;
	}

	private static PriorityQueue<UserAndSimilarity> Similarity(int[] testExample, int[][] datasetTrain, int k) {
		PriorityQueue<UserAndSimilarity> pq = new PriorityQueue<>();

		double xiSquare = 0, yiSquare = 0, xiyi = 0, xi, yi;
		double similarity;

		for (int i = 1; i < datasetTrain.length; i++) {
			for (int j = 1; j < cntItem; j++) {
				xi = testExample[j];
				yi = datasetTrain[i][j];
				xiyi += xi * yi;
				xiSquare += xi * xi;
				yiSquare += yi * yi;
			}
			similarity = xiyi / Math.sqrt(xiSquare * yiSquare);
			addToQueue(i, similarity, pq, k);
		}
		return pq;
	}

	private static void addToQueue(int i, double similarity, PriorityQueue<UserAndSimilarity> pq, int k) {
		
		//Generating k columns of neighbours based on similarity
		if (k <= pq.size()) {
			final UserAndSimilarity firstElm = pq.peek();
			if (Double.compare(similarity, firstElm.similarity) < 1) {
				return;
			} else {
				pq.poll();
			}
		}
		pq.add(new UserAndSimilarity(i, similarity));

	} 

	public static int[][] fileLoader(String TextFile) {

		int[][] datasetTrain = new int[cntUser][cntItem];
		BufferedReader br = null;
		String line = "";

		try {
			// Parsing the Textfile into ArrayList.
			br = new BufferedReader(new FileReader(TextFile));
			while ((line = br.readLine()) != null) {
				if (line.length() > 0) {
					String[] cell = line.split("\t");
					datasetTrain[Integer.valueOf(cell[0])][Integer.valueOf(cell[1])] = Integer.valueOf(cell[2]);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return datasetTrain;
	}

	//cntItem Based similarity measures 
	public static int[][] fileLoaderOne(String TextFile) {

		int[][] traindataOne = new int[cntUser][cntItem];
		BufferedReader br = null;
		String line = "";
		int cnt=0;
		try {
			// Parsing the Textfile into ArrayList.
			br = new BufferedReader(new FileReader(TextFile));
			while ((line = br.readLine()) != null) {
				if (line.length() > 0) {
					String[] cell = line.split("\t");
					traindataOne[Integer.valueOf(cell[1])][Integer.valueOf(cell[0])] = Integer.valueOf(cell[2]);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return traindataOne;
	}

	static class UserAndSimilarity implements Comparable<UserAndSimilarity> {

		public Integer userid;
		public double similarity;

		public UserAndSimilarity(Integer userid, double similarity) {
			this.userid = userid;
			this.similarity = similarity;
		}

		public int compareTo(UserAndSimilarity o) {
			return Double.compare(o.similarity, similarity);
		}
	}
}
