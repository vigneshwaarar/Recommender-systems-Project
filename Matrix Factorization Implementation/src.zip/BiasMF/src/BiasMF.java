import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

public class BiasMF {

	public BiasMF() {
		// TODO Auto-generated constructor stub
	}
	static int cntUser = 944;
	static int cntItem = 1683;
 	static int k = 5;
 	static double rate = 0.0001;
 	static String inputExtension = "";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		inputExtension = args[1];
		if(inputExtension.equals("0"))
			System.out.println("Baised Matrix Factorization !");
		else
			System.out.println("Baised Matrix Factorization with extension !");
		//System.out.println("Given settings: k = " + k + " learning rate: " + " regularization rate:" + );
		//k = Integer.parseInt(args[3]);
		rate = Double.parseDouble(args[5]);
		double regularization = Double.parseDouble(args[7]);
		k = Integer.parseInt(args[3]);
		int[][] datasetTrain = fileLoader("train.txt");
		for(int i=0 ; i< datasetTrain.length; i++)
		{
			for(int j=0 ; j < datasetTrain[i].length;j++)
			{
				//System.out.println(datasetTrain[i][j] +" ");
			}
		}
		int[][] datasetTest = fileLoader("test.txt");
		
		double[][] matrixUser = new double[cntUser][k];
		double[][] matrixItem = new double[cntItem][k];
		//Arrays.fill(matrixUser , 0.001);
		for (double[] row: matrixUser )
		    Arrays.fill(row, 0.01);
		for (double[] row: matrixItem)
		    Arrays.fill(row, 0.01);
		//Arrays.fill(matrixItem , 0.001);
		double SSEvalue = 0.0;
		double[][] ratingPredict = new double[cntUser][cntItem];
		for(int i=0; i<matrixUser.length;i++)
		{
			for(int j=0; j<matrixItem.length;j++)
			{
				double rating = 0.0;
				for(int w=0;w<5;w++)
				{
					rating += matrixUser[i][w] * matrixItem[j][w];
				}
				ratingPredict[i][j] =rating;
				if(datasetTrain[i][j] != 0)
					SSEvalue += (double)datasetTrain[i][j] - rating;
				
				//matrixUser[i][w] = matrixUser[i][w] - (2 * rate *(datasetTrain[i][j]- rating));
			}
		}
		//System.out.println("SSE1: "+SSEvalue);
		double count = 0.0;
		Random rand = new Random();
		int x = rand.nextInt(9);
		//System.out.println(x);
		rate = ((double)x)/100;
		for(int t=0; t < k; t++)
		{	
			SSEvalue = 0.0;
			count = 0.0;
			for(int i=0; i<matrixUser.length;i++)
			{
				for(int j=0; j<matrixItem.length;j++)
				{
					double rating = 0.0;
					for(int w=0;w<5;w++)
					{
						if(datasetTrain[i][j] != 0)
						{
							if(inputExtension== "1")
							{	
								double r = matrixUser[i][w] * matrixItem[j][w];
								double item = matrixItem[j][w];
								double user = matrixUser[i][w];
								double predic = (double)datasetTrain[i][j];
								double biasUser = 0.0;
								double biasItem = 0.0;
								//System.out.println(r +" "+ item + " " + user + " " + predic);
								biasUser = biasUser * matrixUser[i][w];
								biasItem = biasItem * matrixItem[j][w];
								
								matrixUser[i][w] = biasUser + matrixUser[i][w]+(2 * rate * item * (predic - r));
								matrixItem[j][w] = biasItem + matrixItem[j][w]+(2 * rate * user * (predic - r));
								rating += matrixUser[i][w] * matrixItem[j][w];
							}
							else
							{
								double r = matrixUser[i][w] * matrixItem[j][w];
								double item = matrixItem[j][w];
								double user = matrixUser[i][w];
								double predic = (double)datasetTrain[i][j];
								double biasUser = 0.0;
								double biasItem = 0.0;
								//System.out.println(r +" "+ item + " " + user + " " + predic);
								biasUser = biasUser * matrixUser[i][w];
								biasItem = biasItem * matrixItem[j][w];
								
								matrixUser[i][w] = biasUser + matrixUser[i][w]+(2 * rate * item * (predic - r));
								matrixItem[j][w] = biasItem + matrixItem[j][w]+(2 * rate * user * (predic - r));
								rating += matrixUser[i][w] * matrixItem[j][w];
							}
								
						}
						count++;
					}
					//System.out.println("Predict: " + rating);
					//ratingPredict[i][j] =rating;
					//System.out.println(ratingPredict[i][j] =rating);
					if(datasetTrain[i][j] != 0)
						SSEvalue += Math.abs((double)datasetTrain[i][j] - rating);
				}
			}
			
		}
		System.out.println("MAE: "+(SSEvalue/count));
	}
	public static int[][] fileLoader(String TextFile) {

		int[][] datasetTrain = new int[cntUser][cntItem];
		BufferedReader br = null;
		String line = "";

		try {
			// Parsing the Textfile into ArrayList.
			br = new BufferedReader(new FileReader(TextFile));
			while ((line = br.readLine()) != null) {
				if (line.length() > 0) {
					String[] cell = line.split("\t");
					datasetTrain[Integer.valueOf(cell[0])][Integer.valueOf(cell[1])] = Integer.valueOf(cell[2]);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return datasetTrain;
	}

}
