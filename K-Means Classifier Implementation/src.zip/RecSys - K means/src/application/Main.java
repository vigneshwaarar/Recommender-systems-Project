package application;
	
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;


public class Main extends Application {
	ArrayList<ArrayList<String>> listOListsTrain = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listOListsTest = new ArrayList<ArrayList<String>>();
	Map<Integer, Map<Integer,ArrayList<String>>> classHMap = new HashMap<Integer, Map<Integer,ArrayList<String>>>();
	Map<Integer, ArrayList<String>> centroidHMap = new HashMap<Integer, ArrayList<String>>();
	String strAcc = "";
	ArrayList<String> singleList = null;
	String Path = "";
	int classCount = 0;
	String strDistance = "";
	String cvsSplitBy = ",";
	int kValue = 0;
	int maxItr = 0;
	int featureCount = 0;
	double Accuracy = 0;
	@Override
	public void start(Stage primaryStage) {
		try {
			Stage stgFileLoading = new Stage();
			primaryStage.setTitle("Upload File");
			primaryStage.setTitle("K-means Clustering");
			GridPane grid = new GridPane();
			grid.setAlignment(Pos.CENTER);
			grid.setHgap(10);
			grid.setVgap(10);
			grid.setPadding(new Insets(25, 25, 25, 25));

			Scene scene = new Scene(grid, 300, 275);
			primaryStage.setScene(scene);
			Text scenetitle = new Text("Welcome");
			scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
			grid.add(scenetitle, 0, 0, 2, 1);
			Label lblKValue = new Label("Enter K value:");
			grid.add(lblKValue, 0, 1);
			
			TextField txtKValue = new TextField();
			TextField txtMaxItr = new TextField();
			grid.add(txtKValue, 1, 1);
			
			final ToggleGroup group = new ToggleGroup();
			RadioButton rb1 = new RadioButton("Manhattan");
			rb1.setToggleGroup(group);
			rb1.setSelected(true);
			
			RadioButton rb2 = new RadioButton("Euclidean");
			rb2.setToggleGroup(group);
			HBox rbContainer = new HBox(rb1, rb2);
			Label lblDistance = new Label("Distance Measure:");
			Label lblMaxItr = new Label("Max Iteration:");
			grid.add(lblDistance, 0, 2);
			grid.add(lblMaxItr, 0, 3);
			grid.add(rbContainer, 1, 2);
			grid.add(txtMaxItr, 1, 3);
			Label lblTrainingDS = new Label("Select dataset:");
			//Label lblTestingDS = new Label("Select Testing dataset:");
			//grid.add(lblTrainingDS, 0, 3);
			grid.add(lblTrainingDS, 0, 4);
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Open Resource File");
			Button btnTrain = new Button("dataset");
			btnTrain.setMaxWidth(140);
			//Button btnTest = new Button("Test data");
			//btnTest.setMaxWidth(140);
			Button btnClassify = new Button("Classify");
			btnClassify.setMaxWidth(140);
			grid.add(btnTrain, 1, 4);
			//grid.add(btnTrain, 1, 4);
			grid.add(btnClassify, 0, 5);
			Text errorMess = new Text("");
			grid.add(errorMess, 0, 6, 2, 1);
			/*Event handler for the button btnTrain*/
			btnTrain.setOnAction(new EventHandler<ActionEvent>() {
			     public void handle(ActionEvent e) {
			    	File fileTrain = fileChooser.showOpenDialog(stgFileLoading);
			    	btnTrain.setText("data Loaded");
			    	//System.out.println(fileTrain);
			    	try {
			    		String line = "";
						BufferedReader br = new BufferedReader(new FileReader(fileTrain));
						 while ((line = br.readLine()) != null) 
					        {
							 	singleList = new ArrayList<String>();
					            // use comma as separator
					            String[] data = line.split(cvsSplitBy);
					            for(int i=0; i < data.length; i++)
					            {
					            	singleList.add(data[i]);
					            }

					            listOListsTrain.add(singleList);
					        }
						 //System.out.println(listOListsTrain);
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			    	
			    }
			});
			/*Event handler for the button btnTest*/
			
			btnClassify.setOnAction(new EventHandler<ActionEvent>() {
			     public void handle(ActionEvent e) {
			    	 if(txtKValue.getText()!=null && txtKValue.getText()!="" && !txtKValue.getText().equals("") && txtMaxItr.getText()!=null && txtMaxItr.getText()!="" && !txtMaxItr.getText().equals(""))
			    	 {
			    		 
			    		 try {
			    			 kValue = Integer.parseInt(txtKValue.getText());
			    			 maxItr = Integer.parseInt(txtMaxItr.getText());
			    			 errorMess.setText("");
			    			 if(rb1.isSelected())
					    		 strDistance = rb1.getText();
					    	 else
					    		 strDistance = rb2.getText();
					    	 //System.out.println(kValue + " : "+ strDistance);
				    		 try {
						    		 if(listOListsTrain.size() != 0 && kValue !=0)
						    		 {
						    			 errorMess.setText("");
						    			 //errorMess.setText("Accuracy of the model: " + classifier()  + "%");
						    			 errorMess.setText("SSE: "+ classifier());
						    		 }
						    		 else
						    		 {
						    			 if(listOListsTrain.size() == 0)
						    				 errorMess.setText("Please select dataset");
						    			 else if(kValue == 0)
						    				 errorMess.setText("Please enter valid K value");
						    			 else
						    				 errorMess.setText("Please enter valid Max Iteration value");
						    		 }
						    			  
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
			    		 }catch (NumberFormatException ex) {
			    			 	errorMess.setText("K is not a number.");
			    			 	kValue = 0;
			    			    System.out.println("K is not a number.");
			    			}
			    		 
			    	 }
			    	 else if(txtKValue.getText()==null || txtKValue.getText()=="" || txtKValue.getText().equals(""))
			    	 {
			    		 errorMess.setText("Please enter k-value");
			    		 System.out.println("Please enter k-value");
			    	 }
			    	 else 
			    	 {
			    		 errorMess.setText("Please enter Max iteration limit");
			    		 System.out.println("Please enter Max iteration limit");
			    	 }
			     }
			});
			
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
/* Function which holds the algorithm implementation*/
	private Double classifier() throws IOException {
		// TODO Auto-generated method stub
		Double doubleSSE = 0.0;
		if(listOListsTrain.size() != 0 )
		{
			featureCount = listOListsTrain.get(0).size();
			int cenValue = (listOListsTrain.size())/kValue;
			//System.out.println(cenValue);
			int count =0;
			for(int i=0; i < kValue; i++)
			{
				count += cenValue-1;
				centroidHMap.put(i+1, listOListsTrain.get(count));
				//count++;
			}
			distanceCalc("first");
			
			for(int i=1; i<= maxItr-1; i++)
			{
				centroidCalc();
				distanceCalc("second");
				doubleSSE = calcSSE();
			}
			System.out.println("Centroid:");
			System.out.println(centroidHMap);
			System.out.println("Clusters:");
			System.out.println(classHMap);
			File f = new File("out.txt");
			f.delete();
			BufferedWriter writer = new BufferedWriter (new FileWriter("out.txt"));
			for(int k=0; k <kValue; k++)
			{
				writer.write("Cluster "+(k+1)+ ":");
				//System.out.println("Cluster "+(k+1)+ ":");
				writer.newLine();
				for(int key: classHMap.get(k+1).keySet())
				{
					for(int i=0;i<featureCount; i++)
					{
						writer.write(classHMap.get(k+1).get(key).get(i) + " ");
						//System.out.print(classHMap.get(k+1).get(key).get(i) + " ");
					}
					writer.newLine();
				}
			}

			writer.close();
			System.out.println("Max Iteration: "+ maxItr +", SSE: "+ doubleSSE);
			
		}
		return doubleSSE;
		
	}
	/*Function to claculate SSE*/
	public Double calcSSE()
	{
		Double measureSSE = 0.0;
		for(int i = 0; i< kValue; i++)
		{
			Iterator it = classHMap.get(i+1).entrySet().iterator();
		    while (it.hasNext()) 
		    {
		    	Map.Entry pair = (Map.Entry)it.next();
		    	ArrayList<String> tempAL2 = new ArrayList<String>(classHMap.get(i+1).get(pair.getKey()));
		    	for(int j=0; j< featureCount-1; j++)
				{
		    		measureSSE += Math.pow(Double.parseDouble(tempAL2.get(j))-Double.parseDouble(centroidHMap.get(i+1).get(j)),2);
				}
		    }
		}
		//System.out.println(measureSSE);
		return measureSSE;
	}
	/*Function to calculate Centroid for cluster*/
	public void centroidCalc()
	{
		for(int i = 0; i< kValue; i++)
		{
			Map<Integer, ArrayList<String>> tempHMap = new HashMap<Integer, ArrayList<String>>();
			ArrayList<String> tempAL1 = new ArrayList<String>();
			for(int j=0; j< featureCount-1; j++)
			{				
				Double measureD = 0.0;
				Iterator it = classHMap.get(i+1).entrySet().iterator();
			    while (it.hasNext()) 
			    {
			    	Map.Entry pair = (Map.Entry)it.next();
			    	
			    	ArrayList<String> tempAL2 = new ArrayList<String>(classHMap.get(i+1).get(pair.getKey()));
			    	//System.out.println(pair.getValue());
			    	measureD += Double.parseDouble(tempAL2.get(j));
			    }
			    
			    measureD = (measureD)/classHMap.get(i+1).size();
			    tempAL1.add(measureD.toString());
			}
			centroidHMap.put(i+1, tempAL1);
		}
		//return centroidHMap;
	}
	/*Function to calculate different distance measure*/
	public void distanceCalc(String s)
	{
		classHMap.clear();
		MathContext mc = new MathContext(2);
		for(int i=0; i< listOListsTrain.size();i++)
		{
			//double dis = 0;
			Map<Integer, Double> disHMap = new HashMap<Integer, Double>();
			//ArrayList<ArrayList<Double>> l = new ArrayList<ArrayList<Double>>();
			for(int j=0; j< centroidHMap.size(); j++)
			{
				double dis = 0;
				for(int k=0; k < centroidHMap.get(j+1).size()-1; k++)
				{
					BigDecimal value1 = new BigDecimal(listOListsTrain.get(i).get(k));
					BigDecimal value2 = new BigDecimal(centroidHMap.get(j+1).get(k));
					BigDecimal valuef = value2.subtract(value1,mc);
					if(strDistance.equals("Manhattan"))
					{
						dis += Math.abs(Double.parseDouble(valuef.toString()));
					}
					else
					{
						double tempdis = Math.pow(Double.parseDouble(valuef.toString()),2);
						dis += tempdis;
					}
					
				}
				disHMap.put(j+1, dis);
				//System.out.println(disHMap);
			}
			TreeMap sortedMap = new TreeMap(new ValueComparator(disHMap));
			sortedMap.putAll(disHMap);
			
//			if(s == "first")
//			{
				if(classHMap.containsKey(sortedMap.firstKey()))
					classHMap.get(sortedMap.firstKey()).put(i+1, listOListsTrain.get(i));
				else
				{
					Map<Integer, ArrayList<String>> tempHMap = new HashMap<Integer, ArrayList<String>>();
					tempHMap.put(i+1, listOListsTrain.get(i) );
					classHMap.put((int)sortedMap.firstKey(), tempHMap);
				}
			//}
//			else
//			{
//				Map<Integer, ArrayList<String>> tempHMap = new HashMap<Integer, ArrayList<String>>();
//				tempHMap.put(i+1, listOListsTrain.get(i) );
//				classHMap.put((int)sortedMap.firstKey(), tempHMap);
//			}
		}
	}

	/*MAin function for our class*/
	public static void main(String[] args) {
		launch(args);
	}
}
/* Comparator class to sort the collection*/
class ValueComparator implements Comparator {
	Map map;
 
	public ValueComparator(Map map) {
		this.map = map;
	}
 
	public int compare(Object keyA, Object keyB) {
		Comparable valueA = (Comparable) map.get(keyA);
		Comparable valueB = (Comparable) map.get(keyB);
		return valueA.compareTo(valueB);
	}
}